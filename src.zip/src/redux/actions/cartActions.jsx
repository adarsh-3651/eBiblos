// src/redux/actions/cartActions.js

export const ADD_TO_CART = "ADD_TO_CART";
export const REMOVE_FROM_CART = "REMOVE_FROM_CART";
export const CLEAR_CART = "CLEAR_CART";

/**
 * Adds a book to the cart.
 * @param {Object} book - The book object containing id, title, price, etc.
 */
export const addToCart = (book) => {
    return {
        type: ADD_TO_CART,
        payload: book,
    };
};

/**
 * Removes a book from the cart using its ID.
 * @param {string} bookId - The unique ID of the book to be removed.
 */
export const removeFromCart = (bookId) => {
    return {
        type: REMOVE_FROM_CART,
        payload: bookId,
    };
};

/**
 * Clears all items from the cart.
 */
export const clearCart = () => {
    return {
        type: CLEAR_CART,
    };
};

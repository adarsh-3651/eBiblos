import React from 'react'

function Help() {
  return (
    <div className='bg-amber-600'>Help</div>
  )
}

export default Help
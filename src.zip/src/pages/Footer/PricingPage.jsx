import React from 'react'

function PricingPage() {
  return (
    <div>PricingPage</div>
  )
}

export default PricingPage
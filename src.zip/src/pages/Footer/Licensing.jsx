import React from 'react'

function Licensing() {
  return (
    <div>Licensing</div>
  )
}

export default Licensing
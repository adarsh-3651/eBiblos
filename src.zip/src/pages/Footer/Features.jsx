import React from 'react'

function Features() {
  return (
    <div>Features</div>
  )
}

export default Features